# The impact of weather conditions on cycling counts in Auckland, New Zealand 

Pleas follow this Jupyter Notebook:

[https://github.com/nicolasfauchereau/Auckland_Cycling/blob/master/notebooks/Auckland_cycling_and_weather.ipynb](https://github.com/nicolasfauchereau/Auckland_Cycling/blob/master/notebooks/Auckland_cycling_and_weather.ipynb)
